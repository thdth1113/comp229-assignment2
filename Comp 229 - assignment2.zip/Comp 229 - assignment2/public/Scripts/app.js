/*
Student Name: Sohyeon Song
Student ID: 301145311
*/

//Outputs the message 
(function(){

    function Start()
    {
        console.log("App Started...");

        let dangerButtons = document.getElementsByClassName("btn-danger");

        for (const button of dangerButtons) {
            button.addEventListener('click', (event) => {
                if(!confirm("Are you sure?"))
                {
                    event.preventDefault();
                    location.href = '/component-list';
                }
            });
        }
    }

    window.addEventListener('load', Start);
})();