//module.exports.URL = "mongodb://localhost:27017/computer_store";
module.exports.URL = "mongodb+srv://Sohyeon:<password>@cluster0.uymo9.mongodb.net/myFirstDatabase?retryWrites=true&w=majority";