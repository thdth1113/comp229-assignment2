/* 
Student Name: Sohyeon Song
Student ID: 301145311
*/
//installed required packages for the server to run
let createError = require('http-errors');
let express = require('express');
let path = require('path');
let cookieParser = require('cookie-parser');
let logger = require('morgan');

let indexRouter = require('./routes/index');
let usersRouter = require('./routes/users');

let app = express();

//modules for authentication
let session = require('express-session');
let passport = require('passport');
let passportlocal = require('passport-local');

//authentication objects
let localStrategy = passportlocal.Strategy; //alias
let userModel = require('../models/user');
let User = userModel.User; //alias

//module for auth messaing and error management
let indexRouter = require('../routes/index');
let componentRouter = require('../routes/component');
let usersRouter = require('../routes/users');

let app = express();

//database setup and connection
let mongoose = require('mongoose');
let DB = require('./DB');

mongoose.connect(DB.URL, {userNewUrlParser:true, useUnifiedTopology:true});
let dbconnection = mongoose.connection;

dbconnection.on('error',console.error.bind(console,'connection error:'));
dbconnection.once('open',()=>{
  console.log('MongoDB Connection OPEN');
});

dbconnection.once('connected',()=>{
  console.log('MongoDB Connected');
});

dbconnection.once('disconnected',()=>{
  console.log('MongoDB Disconnected');
});

dbconnection.once('reconnected',()=>{
  console.log('MongoDB Reconnected');
});

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.static(path.join(__dirname, 'node_modules')));


app.use('/', indexRouter);
app.use('/users', usersRouter);

//setup express session
let Auth = require('./auth');
app.user(session({
  secret:Auth.secret,
  saveUninitialized:false,
  resave:false
}));

//initialize flash
app.user(flash());

//initialize passport
app.use(passport.initialize());
app.use(passport.session());

//implement Auth Strategy
passport.use(User.createStrategy());

//serialize and deserialize the user data
passport.serializeUser(User.serializeUser());
passport.deserializeUser(User.deserializeUser());

app.use('/', indexRouter);
app.use('/component-list',componentRouter);
app.use('/users',usersRouter);

// catch 404 and forward to error handler
app.use(function(req, res, next) {
  next(createError(404));
});

// error handler
app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});

module.exports = app;
