/*
Student Name: Sohyeon SOng
Student ID: 301145311
*/

var express = require('express');
var router = express.Router();

/* GET users list. */
router.get('/', function(req, res, next) {
  res.send('Placeholder');
});

module.exports = router;
